"""
    Codes in the following package are adapted from
    https://github.com/liuyukid/transformers-ner , including:

    - deeplearning.entity.infer.base;
    - deeplearning.entity.models.*;
    - deeplearning.entity.utils.*;
"""

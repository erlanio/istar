from .agent_dative_ADP import agent_dative_adp
from .dep import dep_base as dep
from .ner import ner
from .poss_PROPN import poss_propn
from .tag import tag_base as tag
from .word_list import word_list

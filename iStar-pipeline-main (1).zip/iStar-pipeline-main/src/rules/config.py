# actor_plugins: RulePlugins = (
#     dative_propn,
#     relcl_who,
#     actor_tag,
#     actor_dep,
#     # actor_word_list,
#     # actor_ner,
#     xcomp_ask,
#     be_nsubj,
#     by_sb,
# )

# resource_plugins: RulePlugins = (
#     # resource_dep,
#     # resource_ner,
#     # resource_tag,
#     agent_dative_adp,
#     poss_propn,
#     resource_word_list,
# )

# intention_aux_slice_plugins: IntentionAuxPlugins = (
#     awt_slice,
#     relcl_slice,
#     agent,
# )

# intention_plugins: RulePlugins = (
#     # xcomp_to,
#     acl_to,
#     # acl_without_to,
#     # relcl,
#     # pcomp_ing,
#     # advcl,
# )
